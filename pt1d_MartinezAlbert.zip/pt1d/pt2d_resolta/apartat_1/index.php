<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title>Biblioteca</title>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<meta http-equiv="Content-Language" content="es" />
	</head>
	<body>
			<a href="view/menu_llibre.php">Menú Llibre</a><br>
			<a href="view/menu_autor.php">Menú Autor</a><br>
	</body>
</html>
