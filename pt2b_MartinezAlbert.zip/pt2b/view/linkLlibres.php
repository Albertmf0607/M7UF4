<?php
	function linkLlibres() {
		echo '<br/> <a href="../view/menu_llibre.php">Torna</a>';

	}
?>
