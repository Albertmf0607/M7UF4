<?php
	function linkAutors() {
		echo '<br/> <a href="../view/menu_autor.php">Torna</a>';

	}
?>
