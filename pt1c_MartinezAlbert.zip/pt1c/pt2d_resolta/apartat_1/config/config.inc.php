<?php
	$GLOBALS['baseUrl'] = "localhost/M7/UF4/pt1/public/index.php";
?>
